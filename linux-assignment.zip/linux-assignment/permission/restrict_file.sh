#!/bin/bash
echo "umask 777" | sudo tee -a /etc/profile
