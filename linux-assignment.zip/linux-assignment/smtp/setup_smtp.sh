#!/bin/bash
sudo apt install postfix mailutils -y
